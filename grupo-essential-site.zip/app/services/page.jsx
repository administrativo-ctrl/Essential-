import { services } from "../../lib/data";
import ServiceCard from "../../components/ServiceCard";

export const metadata = {
  title: "Serviços — Essential Marketing"
};

export default function ServicesPage(){
  return (
    <section className="container py-12">
      <h1 className="text-3xl font-bold">Serviços</h1>
      <p className="mt-2 text-essential-gray600 max-w-3xl">
        Atuamos ponta a ponta para tirar seu marketing do achismo: estratégia, conteúdo, tráfego e audiovisual.
      </p>
      <div className="mt-8 grid md:grid-cols-3 gap-6">
        {services.map(s => <ServiceCard key={s.key} title={s.title} desc={s.desc}/>)}
      </div>
    </section>
  );
}
