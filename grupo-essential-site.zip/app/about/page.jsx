export const metadata = { title: "Sobre — Grupo Essential" };

export default function AboutPage(){
  return (
    <section className="container py-12">
      <h1 className="text-3xl font-bold">Sobre o Grupo Essential</h1>
      <p className="mt-3 text-essential-gray600 max-w-3xl">
        Nascemos em Teresópolis para criar crescimento real — para marcas e pessoas. Acreditamos em processos claros, estética forte e foco em resultado.
      </p>
      <div className="grid md:grid-cols-3 gap-6 mt-8">
        <div className="card">
          <h3 className="font-semibold">Thainá Justino</h3>
          <p className="text-essential-gray600 mt-2">Founder & Estratégia</p>
        </div>
        <div className="card">
          <h3 className="font-semibold">Helena</h3>
          <p className="text-essential-gray600 mt-2">Gestão de Projetos / Social</p>
        </div>
        <div className="card">
          <h3 className="font-semibold">Gabriel</h3>
          <p className="text-essential-gray600 mt-2">Edição & Audiovisual</p>
        </div>
      </div>
    </section>
  );
}
