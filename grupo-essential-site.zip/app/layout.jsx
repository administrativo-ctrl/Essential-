import "./globals.css";
import Header from "../components/Header";
import Footer from "../components/Footer";

export const metadata = {
  title: "Grupo Essential — Essential Marketing",
  description: "Agência boutique de marketing que entrega rumo e resultado para negócios de serviços.",
  openGraph: {
    title: "Grupo Essential — Essential Marketing",
    description: "Agência boutique de marketing que entrega rumo e resultado para negócios de serviços.",
    images: ["/og-default.jpg"],
    type: "website",
    locale: "pt_BR"
  }
};

export default function RootLayout({ children }){
  return (
    <html lang="pt-BR">
      <body>
        <Header/>
        <main id="main">{children}</main>
        <Footer/>
      </body>
    </html>
  );
}
