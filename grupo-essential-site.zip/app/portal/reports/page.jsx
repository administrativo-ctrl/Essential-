"use client";
import Guard from "../../../components/Guard";
export default function Reports(){
  return (
    <Guard>
      <h1 className="text-2xl font-bold mb-4">Relatórios</h1>
      <div className="card">
        <p className="text-essential-gray600">Gráficos e KPIs do período selecionado.</p>
        <div className="mt-4 grid md:grid-cols-2 gap-6">
          <div className="card">
            <h3 className="font-semibold mb-2">Alcance por semana</h3>
            <div className="h-40 bg-essential-gray100 rounded-lg"></div>
          </div>
          <div className="card">
            <h3 className="font-semibold mb-2">Leads por canal</h3>
            <div className="h-40 bg-essential-gray100 rounded-lg"></div>
          </div>
        </div>
        <div className="mt-4">
          <button className="btn btn-secondary">Exportar PDF</button>
        </div>
      </div>
    </Guard>
  );
}
