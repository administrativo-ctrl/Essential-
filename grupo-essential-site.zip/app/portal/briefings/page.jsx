"use client";
import Guard from "../../../components/Guard";
import { useState } from "react";

export default function Briefings(){
  const [okMsg,setOkMsg]=useState("");
  function submit(e){
    e.preventDefault();
    setOkMsg("Briefing recebido! Obrigado.");
  }
  return (
    <Guard>
      <h1 className="text-2xl font-bold mb-4">Briefings</h1>
      <form className="card grid gap-4" onSubmit={submit}>
        <label className="grid gap-2">
          <span>Título do pedido</span>
          <input className="border rounded-xl px-3 py-2" required/>
        </label>
        <label className="grid gap-2">
          <span>Descrição</span>
          <textarea className="border rounded-xl px-3 py-2" rows={4} required></textarea>
        </label>
        <label className="grid gap-2">
          <span>Link(s) de referência</span>
          <input className="border rounded-xl px-3 py-2" placeholder="https://..." />
        </label>
        <button className="btn btn-primary w-full md:w-auto" type="submit">Enviar briefing</button>
        {okMsg && <p className="text-green-700">{okMsg}</p>}
      </form>
      <div className="mt-8 card">
        <h3 className="font-semibold">Histórico de solicitações</h3>
        <ul className="mt-3 text-sm text-essential-gray600 space-y-2">
          <li>Campanha Setembro — <span className="badge">Aprovado</span></li>
          <li>Reels Semana 38 — <span className="badge">Em produção</span></li>
        </ul>
      </div>
    </Guard>
  );
}
