"use client";
import KPI from "../../../components/KPI";
import Guard from "../../../components/Guard";
export default function Dashboard(){
  return (
    <Guard>
      <div className="grid md:grid-cols-4 gap-6">
        <KPI label="Alcance (30d)" value="120.4k" delta={18}/>
        <KPI label="Engajamento (30d)" value="6.2k" delta={12}/>
        <KPI label="Leads (30d)" value="214" delta={22}/>
        <KPI label="ROI (30d)" value="3.4x" delta={9}/>
      </div>
      <div className="mt-8 card">
        <h3 className="font-semibold">Atividades recentes</h3>
        <ul className="list-disc pl-5 mt-3 text-sm text-essential-gray600 space-y-2">
          <li>Relatório mensal de setembro enviado.</li>
          <li>3 posts aguardando aprovação.</li>
          <li>Briefing “Campanha Outubro” recebido.</li>
        </ul>
      </div>
    </Guard>
  );
}
