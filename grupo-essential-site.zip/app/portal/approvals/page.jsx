"use client";
import Guard from "../../../components/Guard";
export default function Approvals(){
  const items = [
    { id:1, title:"Post 01 — Outubro Rosa", type:"post" },
    { id:2, title:"Reel 02 — Antes & Depois", type:"reel" },
    { id:3, title:"Carrossel 03 — Dica da Semana", type:"carrossel" }
  ];
  return (
    <Guard>
      <h1 className="text-2xl font-bold mb-4">Aprovações</h1>
      <div className="grid md:grid-cols-3 gap-6">
        {items.map(it => (
          <div key={it.id} className="card">
            <div className="aspect-video rounded-lg bg-essential-gray100 mb-3"></div>
            <h3 className="font-semibold">{it.title}</h3>
            <div className="mt-3 flex gap-2">
              <button className="btn btn-primary">Aprovar</button>
              <button className="btn btn-secondary">Pedir ajuste</button>
            </div>
          </div>
        ))}
      </div>
    </Guard>
  );
}
