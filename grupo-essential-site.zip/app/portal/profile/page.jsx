"use client";
import Guard from "../../../components/Guard";
import { useRouter } from "next/navigation";

export default function Profile(){
  const router = useRouter();
  function logout(){
    localStorage.removeItem("essential_portal");
    router.push("/portal/login");
  }
  return (
    <Guard>
      <h1 className="text-2xl font-bold mb-4">Perfil</h1>
      <div className="card">
        <p className="text-essential-gray600">Empresa: Cliente Exemplo LTDA</p>
        <p className="text-essential-gray600 mt-1">Contato: cliente@exemplo.com</p>
        <button className="btn btn-secondary mt-4" onClick={logout}>Sair</button>
      </div>
    </Guard>
  );
}
