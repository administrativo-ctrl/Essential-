"use client";
import Guard from "../../../components/Guard";
export default function Courses(){
  const list = [
    { id:1, title:"Reels que convertem (saúde)", dur:"8 min", progress:"3/6" },
    { id:2, title:"Copy simples para serviços", dur:"9 min", progress:"1/5" }
  ];
  return (
    <Guard>
      <h1 className="text-2xl font-bold mb-4">Cursos</h1>
      <div className="grid md:grid-cols-2 gap-6">
        {list.map(c => (
          <div key={c.id} className="card">
            <div className="aspect-video bg-essential-gray100 rounded-lg mb-3"></div>
            <h3 className="font-semibold">{c.title}</h3>
            <p className="text-sm text-essential-gray600">Duração: {c.dur} • Progresso: {c.progress}</p>
            <button className="btn btn-primary mt-3">Assistir</button>
          </div>
        ))}
      </div>
    </Guard>
  );
}
