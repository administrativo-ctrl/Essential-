export const metadata = { title: "Contato — Grupo Essential" };

export default function ContactPage(){
  return (
    <section className="container py-12">
      <h1 className="text-3xl font-bold">Contato</h1>
      <p className="mt-2 text-essential-gray600">Preencha e receba uma proposta personalizada.</p>
      <form className="card mt-6 grid gap-4" onSubmit={(e)=>{e.preventDefault(); alert('Recebido! Em breve entraremos em contato.')}}>
        <label className="grid gap-2">
          <span>Nome</span>
          <input required className="border rounded-xl px-3 py-2" name="name" />
        </label>
        <label className="grid gap-2">
          <span>WhatsApp</span>
          <input required className="border rounded-xl px-3 py-2" name="whatsapp" inputMode="tel" />
        </label>
        <label className="grid gap-2">
          <span>Segmento</span>
          <select className="border rounded-xl px-3 py-2" name="segment">
            <option>Médicos</option>
            <option>Advogados</option>
            <option>Estética</option>
            <option>PME de Serviços</option>
          </select>
        </label>
        <label className="grid gap-2">
          <span>Objetivo principal</span>
          <input className="border rounded-xl px-3 py-2" name="goal" placeholder="ex.: captar mais agendamentos" />
        </label>
        <label className="inline-flex items-center gap-2">
          <input type="checkbox" required /> <span>Autorizo contato (LGPD)</span>
        </label>
        <button className="btn btn-primary" type="submit">Enviar</button>
      </form>
    </section>
  );
}
