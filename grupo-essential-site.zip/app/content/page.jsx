import { blog } from "../../lib/data";

export const metadata = { title: "Conteúdos — Grupo Essential" };

export default function ContentPage(){
  return (
    <section className="container py-12">
      <h1 className="text-3xl font-bold">Conteúdos</h1>
      <ul className="mt-6 space-y-3">
        {blog.map(p => (
          <li key={p.slug} className="card">
            <a href={`/content/${p.slug}`} className="font-semibold hover:underline">{p.title}</a>
            <p className="text-sm text-essential-gray600 mt-1">{p.excerpt}</p>
          </li>
        ))}
      </ul>
    </section>
  );
}
