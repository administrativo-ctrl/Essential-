"use client";
import AdminGuard from "../../../components/AdminGuard";

export default function AdminDashboard(){
  return (
    <AdminGuard>
      <section className="container py-12">
        <h1 className="text-3xl font-bold">Admin — Dashboard</h1>
        <div className="grid md:grid-cols-3 gap-6 mt-6">
          <div className="card"><h3 className="font-semibold">Clientes</h3><p className="text-essential-gray600 mt-2">12 ativos</p></div>
          <div className="card"><h3 className="font-semibold">Projetos</h3><p className="text-essential-gray600 mt-2">27 em andamento</p></div>
          <div className="card"><h3 className="font-semibold">Aprovações pendentes</h3><p className="text-essential-gray600 mt-2">5</p></div>
        </div>
      </section>
    </AdminGuard>
  );
}
