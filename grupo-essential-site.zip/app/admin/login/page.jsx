"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";

export default function AdminLogin(){
  const [email,setEmail] = useState("");
  const [pass,setPass] = useState("");
  const [err,setErr] = useState("");
  const router = useRouter();
  function onSubmit(e){
    e.preventDefault();
    if((email==="admin@essentialmarketing.com" && pass==="admin123")){
      localStorage.setItem("essential_portal","admin");
      router.push("/admin/dashboard");
    } else {
      setErr("Use admin@essentialmarketing.com / admin123 (demo).");
    }
  }
  return (
    <section className="container py-12 max-w-md">
      <h1 className="text-3xl font-bold">Admin — Login</h1>
      <form onSubmit={onSubmit} className="card mt-6 grid gap-4">
        <label className="grid gap-2">
          <span>E-mail</span>
          <input className="border rounded-xl px-3 py-2" type="email" value={email} onChange={e=>setEmail(e.target.value)} required />
        </label>
        <label className="grid gap-2">
          <span>Senha</span>
          <input className="border rounded-xl px-3 py-2" type="password" value={pass} onChange={e=>setPass(e.target.value)} required />
        </label>
        {err && <div role="alert" className="text-sm text-red-600">{err}</div>}
        <button className="btn btn-primary" type="submit">Entrar</button>
        <p className="text-sm text-essential-gray600">Demo: admin@essentialmarketing.com / admin123</p>
      </form>
    </section>
  );
}
