import { cases } from "../../../lib/data";

export async function generateStaticParams(){
  return cases.map(c => ({ slug: c.slug }));
}

export default function CaseDetail({ params }){
  const c = cases.find(x => x.slug === params.slug);
  if(!c) return <div className="container py-12">Case não encontrado.</div>;
  return (
    <section className="container py-12">
      <h1 className="text-3xl font-bold">{c.title}</h1>
      <div className="mt-6 grid md:grid-cols-3 gap-8">
        <div className="md:col-span-2">
          <div className="aspect-video rounded-xl bg-essential-gray100 mb-6"></div>
          <h3 className="font-semibold">Estratégia</h3>
          <p className="text-essential-gray600 mt-2">{c.strategy}</p>
        </div>
        <aside className="card">
          <h3 className="font-semibold">Resumo</h3>
          <p className="mt-2"><strong>Problema:</strong> {c.problem}</p>
          <p className="mt-2"><strong>Resultado:</strong> {c.result}</p>
        </aside>
      </div>
    </section>
  );
}
