import { cases } from "../../lib/data";
import CaseCard from "../../components/CaseCard";

export const metadata = { title: "Cases — Essential Marketing" };

export default function CasesPage(){
  return (
    <section className="container py-12">
      <h1 className="text-3xl font-bold">Cases</h1>
      <p className="mt-2 text-essential-gray600 max-w-3xl">Resultados que falam por si.</p>
      <div className="mt-8 grid md:grid-cols-3 gap-6">
        {cases.map(c => <CaseCard key={c.slug} {...c}/>)}
      </div>
    </section>
  );
}
