import Hero from "../components/Hero";
import ServiceCard from "../components/ServiceCard";
import CaseCard from "../components/CaseCard";
import { services, cases, blog } from "../lib/data";

export default function Home(){
  return (
    <>
      <Hero/>
      <section className="container py-12">
        <h2 className="text-2xl md:text-3xl font-bold">O que fazemos</h2>
        <div className="mt-6 grid md:grid-cols-3 gap-6">
          {services.slice(0,6).map(s => <ServiceCard key={s.key} title={s.title} desc={s.desc}/>)}
        </div>
      </section>
      <section className="container py-12">
        <h2 className="text-2xl md:text-3xl font-bold">Cases em destaque</h2>
        <div className="mt-6 grid md:grid-cols-3 gap-6">
          {cases.map(c => <CaseCard key={c.slug} {...c}/>)}
        </div>
      </section>
      <section className="container py-12">
        <h2 className="text-2xl md:text-3xl font-bold">Manifesto</h2>
        <p className="mt-3 text-essential-gray600 max-w-3xl">
          Somos do interior, pensamos grande e formamos líderes. O Grupo Essential nasce em Teresópolis para impulsionar negócios de serviços com estratégia, estética e eficiência — sem achismo.
        </p>
      </section>
      <section className="container py-12">
        <h2 className="text-2xl md:text-3xl font-bold">Conteúdos</h2>
        <ul className="mt-4 space-y-3">
          {blog.map(p => (
            <li key={p.slug} className="card">
              <a href={`/content/${p.slug}`} className="font-semibold hover:underline">{p.title}</a>
              <p className="text-sm text-essential-gray600 mt-1">{p.excerpt}</p>
            </li>
          ))}
        </ul>
      </section>
      <section className="bg-essential-gray100">
        <div className="container py-12 flex flex-col md:flex-row items-center justify-between gap-4">
          <h3 className="text-xl font-semibold">Vamos crescer juntos?</h3>
          <div className="flex gap-3">
            <a className="btn btn-primary" href="/contact">Solicitar Proposta</a>
            <a className="btn btn-secondary" href="https://wa.me/5521XXXXXXXXX" target="_blank" rel="noopener">Falar pelo WhatsApp</a>
          </div>
        </div>
      </section>
    </>
  );
}
